<?php
/**
 * The template for displaying the footer in PWA.
 *
 * @package OceanWP WordPress theme
 * @since   1.8.8
 */

?>

	<?php wp_footer(); ?>
	</body>
</html>
