<?php

if (! class_exists('WP_Customize_Control'))
	return;

require get_template_directory() . '/inc/customizer/buttonset/class-control-buttonset.php';
