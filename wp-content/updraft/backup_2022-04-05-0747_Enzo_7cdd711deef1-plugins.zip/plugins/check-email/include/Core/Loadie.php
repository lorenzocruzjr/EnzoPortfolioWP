<?php namespace CheckEmail\Core;

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.

interface Loadie {

	public function load();
        
}
